const $ = (id) => document.getElementById(id);
const st = (t, ok) => { $('st').textContent = t; $('st').className = ok ? 'ok' : 'bad'; };
chrome.storage.local.get(['key', 'api'], (s) => {
  $('key').value = s.key || '';
  $('api').value = s.api || 'https://n8n.assignover.in/webhook/pre-api';
  if (s.key) check(false);
});
function check(force) {
  $('st').textContent = 'Checking…'; $('st').className = '';
  chrome.runtime.sendMessage({ type: 'status', force: force }, (r) => {
    if (r && r.connected) st('Connected: ' + r.campaigns.length + ' campaigns, ' + r.contactCount + ' contacts.', true);
    else st((r && r.message) || 'Not connected yet.', false);
  });
}
$('go').onclick = () => {
  const key = $('key').value.trim(); const api = $('api').value.trim() || 'https://n8n.assignover.in/webhook/pre-api';
  if (!key) { st('Paste your access key first.', false); return; }
  chrome.storage.local.set({ key: key, api: api, syncedAt: 0 }, () => check(true));
};
