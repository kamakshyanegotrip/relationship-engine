// Relationship Engine extension: adds Save buttons on LinkedIn people search results and profile pages.
// It reads only what is on screen, only when you click Save. It never clicks, browses or messages on LinkedIn.
(() => {
  if (window.__reLoaded) return;
  window.__reLoaded = true;

  const BLUE = '#1f5e7a';
  const APP = 'https://kamakshyanegotrip.github.io/relationship-engine/';
  const ST = { contact: { k: '', e: '', p: '' }, connected: false, campaigns: [], saved: new Set(), camp: '', message: '', loaded: false };
  const CAT_ORDER = ['Travel trade', 'Medical & wellness', 'Academic & research', 'Corporate', 'Government & public sector', 'Media & community'];
  const JUNK = /^(connect|message|follow|following|pending|save|saved|more|view .*profile|•?\s*(1st|2nd|3rd\+?)( degree connection)?|status is .*|premium|verified|he\/him|she\/her|they\/them|open to work|·)$/i;

  const send = (msg) => new Promise((resolve) => {
    try { chrome.runtime.sendMessage(msg, (r) => resolve(r || { ok: false, message: (chrome.runtime.lastError || {}).message || 'No answer from the extension.' })); }
    catch (e) { resolve({ ok: false, message: 'The extension was updated. Reload this LinkedIn tab.' }); }
  });

  const slugOf = (url) => {
    const m = String(url || '').match(/\/in\/([^/?#]+)/i);
    if (!m) return '';
    try { return decodeURIComponent(m[1]).toLowerCase(); } catch (e) { return m[1].toLowerCase(); }
  };
  const cleanUrl = (href) => { const s = String(href || '').match(/\/in\/([^/?#]+)/i); return s ? 'https://www.linkedin.com/in/' + s[1] + '/' : ''; };
  const lines = (el) => {
    const out = [];
    String(el ? el.innerText : '').split('\n').map((l) => l.trim()).filter(Boolean).forEach((l) => {
      if (JUNK.test(l) || /^[·•|]+$/.test(l)) return;
      if (out[out.length - 1] !== l) out.push(l);
    });
    return out;
  };
  const pageType = () => {
    const p = location.pathname;
    if (/^\/in\/[^/]+(\/overlay\/contact-info)?\/?$/.test(p)) return 'profile';
    if (/^\/search\/results\/(people|all)/.test(p)) return 'search';
    return '';
  };

  async function loadStatus(force) {
    const r = await send({ type: 'status', force: !!force });
    ST.loaded = true;
    ST.connected = !!(r && r.connected);
    ST.message = (r && r.message) || '';
    ST.campaigns = (r && r.campaigns) || [];
    ST.saved = new Set((r && r.saved) || []);
    ST.camp = (r && r.camp) || '';
    renderBar();
    document.querySelectorAll('button[data-re-slug]').forEach(markChip);
  }

  // ---------- toast ----------
  let toastEl = null, toastTimer = 0;
  function toast(text, bad) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = 'position:fixed;left:50%;bottom:88px;transform:translateX(-50%);z-index:2147483647;max-width:420px;padding:10px 16px;border-radius:10px;font:600 14px/1.35 -apple-system,Segoe UI,Roboto,Arial,sans-serif;box-shadow:0 6px 24px rgba(0,0,0,.25);color:#fff;';
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = text;
    toastEl.style.background = bad ? '#b3261e' : '#14532d';
    toastEl.style.display = 'block';
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { toastEl.style.display = 'none'; }, bad ? 6000 : 3500);
  }

  // ---------- floating bar ----------
  let host = null, root = null;
  function campOptions() {
    const g = {};
    ST.campaigns.forEach((c) => { (g[c.cat] = g[c.cat] || []).push(c); });
    const esc = (s) => String(s).replace(/[&<>"]/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
    return Object.keys(g).sort((a, b) => ((CAT_ORDER.indexOf(a) + 1) || 99) - ((CAT_ORDER.indexOf(b) + 1) || 99)).map((cat) =>
      '<optgroup label="' + esc(cat) + '">' + g[cat].sort((a, b) => a.name.localeCompare(b.name)).map((c) =>
        '<option value="' + esc(c.code) + '"' + (c.code === ST.camp ? ' selected' : '') + '>' + esc(c.name) + '</option>').join('') + '</optgroup>').join('');
  }
  function renderBar() {
    const type = pageType();
    if (!type) { if (host) { host.remove(); host = null; root = null; } return; }
    if (!host) {
      host = document.createElement('div');
      host.id = 're-bar-host';
      host.style.cssText = 'position:fixed;right:16px;bottom:16px;z-index:2147483646;';
      root = host.attachShadow({ mode: 'open' });
      document.documentElement.appendChild(host);
    }
    const min = sessionStorage.getItem('re-min') === '1';
    const css = '<style>*{box-sizing:border-box;font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif}' +
      '.bar{background:#fff;color:#1d2226;border:1px solid #d0d7de;border-radius:14px;box-shadow:0 8px 28px rgba(0,0,0,.18);padding:10px 12px;width:300px;display:grid;gap:8px}' +
      '.top{display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700}.mark{width:22px;height:22px;border-radius:6px;background:' + BLUE + ';color:#fff;font-size:10px;display:grid;place-items:center;flex:none}' +
      '.x{margin-left:auto;border:0;background:none;cursor:pointer;font-size:16px;color:#666;padding:0 2px}' +
      'select{width:100%;padding:6px 8px;border:1px solid #c4cbd2;border-radius:8px;font-size:13px;background:#fff;color:#1d2226}' +
      'label{font-size:11px;color:#56687a;display:grid;gap:3px}.save{border:0;border-radius:999px;background:' + BLUE + ';color:#fff;font-weight:700;font-size:14px;padding:9px 14px;cursor:pointer}' +
      '.two{display:grid;grid-template-columns:1fr 1fr;gap:6px}input{width:100%;padding:6px 8px;border:1px solid #c4cbd2;border-radius:8px;font-size:13px;color:#1d2226;background:#fff}' +
      '.alt{background:#fff;color:' + BLUE + ';border:1px solid ' + BLUE + ';font-size:13px;padding:7px 12px}' +
      '.save:disabled{opacity:.6;cursor:default}.done{background:#14532d}.hint{font-size:12px;color:#56687a;margin:0;line-height:1.4}a{color:' + BLUE + '}' +
      '.pill{border:0;border-radius:999px;background:' + BLUE + ';color:#fff;font-weight:700;font-size:13px;padding:10px 14px;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.25)}</style>';
    if (min) {
      root.innerHTML = css + '<button class="pill" id="open">Relationship Engine</button>';
      root.getElementById('open').onclick = () => { sessionStorage.removeItem('re-min'); renderBar(); };
      return;
    }
    let body = '';
    if (!ST.loaded) body = '<p class="hint">Connecting…</p>';
    else if (!ST.connected) body = '<p class="hint">' + (ST.message ? ST.message + ' ' : '') + 'Click the Relationship Engine icon in the Chrome toolbar (puzzle piece, then the pin) and paste your access key.</p>';
    else {
      body = '<label>Campaign for people you save<select id="camp">' + campOptions() + '</select></label>';
      if (type === 'profile') {
        const done = ST.saved.has(slugOf(location.href));
        body += '<div class="two"><label>Email<input id="ce" type="email" placeholder="optional"></label><label>Mobile<input id="cp" type="tel" placeholder="optional"></label></div>' +
          '<p class="hint" style="margin-top:-2px">Open <b>Contact info</b> on the profile and these fill in automatically, if they have shared them with you.</p>';
        body += '<button class="save' + (done ? ' done' : '') + '" id="save"' + (done ? ' disabled' : '') + '>' + (done ? 'Saved in Relationship Engine ✓' : 'Save to Relationship Engine') + '</button>';
        if (done) body += '<button class="save alt" id="savec">Save email / mobile</button>';
      } else {
        body += '<p class="hint">Press <b>+ Save</b> next to anyone in the results. For better AI notes, open their profile and save from there.</p>';
      }
    }
    root.innerHTML = css + '<div class="bar"><div class="top"><span class="mark">RE</span>Relationship Engine<button class="x" id="min" title="Minimise">–</button></div>' + body +
      '<p class="hint"><a href="' + APP + '" target="_blank" rel="noopener">Open the app</a></p></div>';
    root.getElementById('min').onclick = () => { sessionStorage.setItem('re-min', '1'); renderBar(); };
    const sel = root.getElementById('camp');
    if (sel) sel.onchange = () => { ST.camp = sel.value; send({ type: 'setCamp', camp: sel.value }); };
    const sv = root.getElementById('save');
    if (sv && !sv.disabled) sv.onclick = () => saveProfile(sv);
    const sc = root.getElementById('savec');
    if (sc) sc.onclick = () => saveContactOnly(sc);
    const ce = root.getElementById('ce'), cp = root.getElementById('cp');
    if (ce && cp) {
      const k = slugOf(location.href);
      if (ST.contact.k !== k) ST.contact = { k: k, e: '', p: '' };
      ce.value = ST.contact.e; cp.value = ST.contact.p;
      ce.oninput = () => { ST.contact.e = ce.value; }; cp.oninput = () => { ST.contact.p = cp.value; };
      fillContact();
    }
  }

  // ---------- contact info (email / mobile), read only from what LinkedIn shows you ----------
  function readContactInfo() {
    const scope = document.querySelector('[role="dialog"]') || document;
    let email = '', phone = '';
    const m = scope.querySelector('a[href^="mailto:"]');
    if (m) email = decodeURIComponent(m.getAttribute('href').slice(7)).split('?')[0].trim();
    const t = scope.querySelector('a[href^="tel:"]');
    if (t) phone = t.getAttribute('href').slice(4);
    if (!phone && scope !== document) {
      const ls = String(scope.innerText || '').split('\n').map((l) => l.trim());
      const i = ls.findIndex((l) => /^phone$/i.test(l));
      const cand = i >= 0 ? ls.slice(i + 1, i + 4).find((l) => /^[+\d][\d\s().-]{7,}/.test(l)) : '';
      if (cand) phone = cand.replace(/\((mobile|work|home)\)/i, '').trim();
    }
    return { email: email, phone: phone.replace(/[^\d+]/g, '') };
  }
  function fillContact() {
    if (!root || pageType() !== 'profile') return;
    const ce = root.getElementById('ce'), cp = root.getElementById('cp');
    if (!ce || !cp) return;
    const ci = readContactInfo();
    if (ci.email && !ce.value) { ce.value = ci.email; ST.contact.e = ci.email; }
    if (ci.phone && !cp.value) { cp.value = ci.phone; ST.contact.p = ci.phone; }
  }
  async function saveContactOnly(btn) {
    const email = ST.contact.e.trim(), phone = ST.contact.p.replace(/[^\d+]/g, '');
    if (!email && !phone) { toast('Type an email or mobile number first, or open Contact info.', true); return; }
    btn.disabled = true; const was = btn.textContent; btn.textContent = 'Saving…';
    const r = await send({ type: 'contact', payload: { linkedin_url: cleanUrl(location.href), email: email, phone: phone } });
    btn.disabled = false; btn.textContent = was;
    if (r && r.ok) toast('Email / mobile saved to Relationship Engine.'); else toast((r && r.message) || 'Could not save.', true);
  }

  // ---------- profile page ----------
  function readProfile() {
    const main = document.querySelector('main') || document.body;
    const h1 = main.querySelector('h1');
    const name = h1 ? h1.innerText.trim() : '';
    const card = h1 ? (h1.closest('section') || h1.parentElement.parentElement) : null;
    let headline = '', loc = '';
    const hEl = card && card.querySelector('.text-body-medium');
    const lEl = card && card.querySelector('.text-body-small.inline');
    if (hEl) headline = hEl.innerText.trim();
    if (lEl) loc = lEl.innerText.trim();
    if (!headline && card) {
      const ls = lines(card).filter((l) => l !== name && !/connections?$|followers?$|contact info/i.test(l));
      headline = ls[0] || ''; loc = loc || ls.find((l) => /,/.test(l) && l.length < 80 && l !== headline) || '';
    }
    const text = String(main.innerText || '').replace(/\n{2,}/g, '\n').slice(0, 3500);
    return { u: cleanUrl(location.href), n: name, h: headline, l: loc, t: text };
  }
  async function saveProfile(btn) {
    const d = readProfile();
    if (!d.u) { toast('Could not read the profile address.', true); return; }
    d.e = ST.contact.e.trim(); d.p = ST.contact.p.replace(/[^\d+]/g, '');
    await persist(d, 'LinkedIn profile (extension)', btn, () => { renderBar(); });
  }

  async function persist(d, source, btn, onDone) {
    if (!ST.camp) { toast('Choose a campaign first.', true); return; }
    btn.disabled = true; const was = btn.textContent; btn.textContent = 'Saving…';
    const p = {
      full_name: d.n || '', linkedin_url: d.u, email: d.e || '', phone: d.p || '', campaign_code: ST.camp, source: source,
      profile_notes: [d.h ? 'Headline: ' + d.h : '', d.l ? 'Location: ' + d.l : '', d.t || ''].filter(Boolean).join('\n')
    };
    const r = await send({ type: 'add', prospect: p });
    if (r && r.ok) {
      ST.saved.add(slugOf(d.u));
      onDone();
      const cn = (ST.campaigns.find((c) => c.code === ST.camp) || {}).name || ST.camp;
      toast('Saved ' + (d.n || 'this person') + ' to “' + cn + '”. AI notes arrive in about a minute.');
    } else {
      btn.disabled = false; btn.textContent = was;
      toast((r && r.message) || 'Could not save.', true);
    }
  }

  // ---------- search results ----------
  // Visible text of a result card, one line per leaf element (skips screen-reader-only text and buttons).
  function cardLines(card) {
    const out = [];
    card.querySelectorAll('*').forEach((el) => {
      if (el.children.length || /^(BUTTON|SVG|IMG|STYLE|SCRIPT)$/i.test(el.tagName)) return;
      if (el.closest('button, [data-re-slug], .visually-hidden, .sr-only')) return;
      const r = el.getBoundingClientRect(); if (r.width <= 1 || r.height <= 1) return;
      const t = (el.textContent || '').replace(/\s+/g, ' ').trim();
      if (!t || JUNK.test(t) || /^[·•|]+$/.test(t)) return;
      if (out[out.length - 1] !== t) out.push(t);
    });
    return out.length ? out : lines(card);
  }
  function markChip(b) {
    if (ST.saved.has(b.dataset.reSlug)) { b.textContent = 'Saved ✓'; b.disabled = true; b.style.background = '#14532d'; b.style.cursor = 'default'; }
  }
  function findCard(a) {
    let card = a.closest('li, [role="listitem"], [data-view-name="search-entity-result-universal-template"]');
    if (card) return card;
    let el = a;
    for (let i = 0; i < 8 && el.parentElement; i++) {
      const up = el.parentElement;
      const slugs = new Set([...up.querySelectorAll('a[href*="/in/"]')].map((x) => slugOf(x.href)));
      if (slugs.size > 1 || up.innerText.length > 900) break;
      el = up;
    }
    return el;
  }
  function scanSearch() {
    if (!ST.connected) return;
    const main = document.querySelector('main') || document.body;
    const seen = new Set();
    main.querySelectorAll('a[href*="/in/"]').forEach((a) => {
      const slug = slugOf(a.href);
      if (!slug || seen.has(slug)) return;
      const txt = (a.innerText || '').trim();
      if (!txt || txt.length > 120) return; // skip photo links and long text
      const card = findCard(a);
      if (!card || card.querySelector('button[data-re-slug]') || card.closest('#re-bar-host')) { seen.add(slug); return; }
      seen.add(slug);
      const b = document.createElement('button');
      b.type = 'button';
      b.dataset.reSlug = slug;
      b.textContent = '+ Save';
      b.title = 'Save to Relationship Engine';
      b.style.cssText = 'all:initial;display:inline-block;margin:4px 0 4px 8px;padding:3px 10px;border-radius:999px;background:' + BLUE + ';color:#fff;font:700 12px/1.6 -apple-system,Segoe UI,Roboto,Arial,sans-serif;cursor:pointer;vertical-align:middle;';
      b.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation();
        const nameEl = a.querySelector('span[aria-hidden="true"]');
        const name = ((nameEl ? nameEl.innerText : txt).split('\n')[0] || '').replace(/^view\s+/i, '').replace(/[’']s profile$/i, '').trim();
        const ls = cardLines(card).filter((l) => l !== name && l.indexOf(name) !== 0 && !/^view .* profile$/i.test(l));
        const d = { u: cleanUrl(a.href), n: name, h: ls[0] || '', l: ls[1] || '', t: 'From LinkedIn search result:\n' + ls.slice(0, 8).join('\n') };
        persist(d, 'LinkedIn search (extension)', b, () => markChip(b));
      }, true);
      markChip(b);
      const anchorBlock = a.parentElement && a.parentElement !== card ? a.parentElement : a;
      anchorBlock.insertAdjacentElement('afterend', b);
    });
  }

  // ---------- page watcher (LinkedIn is a single-page app) ----------
  let lastUrl = '', timer = 0;
  function tick() {
    if (location.href !== lastUrl) { lastUrl = location.href; renderBar(); }
    if (pageType() === 'search') scanSearch();
    if (pageType() === 'profile') fillContact();
  }
  new MutationObserver(() => { clearTimeout(timer); timer = setTimeout(tick, 400); }).observe(document.body, { childList: true, subtree: true });
  chrome.storage.onChanged.addListener((ch) => { if (ch.key || ch.campaigns) loadStatus(false); });
  loadStatus(false).then(tick);
})();
