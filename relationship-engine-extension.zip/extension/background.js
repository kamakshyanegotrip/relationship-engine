// Relationship Engine extension: talks to the n8n API (PRE-05) on behalf of the LinkedIn page.
const DEFAULT_API = 'https://n8n.assignover.in/webhook/pre-api';
const FRESH_MS = 10 * 60 * 1000;

const get = (k) => new Promise((r) => chrome.storage.local.get(k, r));
const set = (o) => new Promise((r) => chrome.storage.local.set(o, r));

function slugOf(url) {
  const m = String(url || '').match(/\/in\/([^/?#]+)/i);
  if (!m) return '';
  try { return decodeURIComponent(m[1]).toLowerCase(); } catch (e) { return m[1].toLowerCase(); }
}

async function call(op, payload) {
  const s = await get(['api', 'key']);
  if (!s.key) throw new Error('Add your access key: click the Relationship Engine icon in the Chrome toolbar.');
  const body = 'data=' + encodeURIComponent(JSON.stringify({ key: s.key, op: op, payload: payload || {} }));
  let res;
  try {
    res = await fetch(s.api || DEFAULT_API, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8' }, body: body });
  } catch (e) { throw new Error('Could not reach n8n. Check the API address in the extension settings.'); }
  let j = null; try { j = await res.json(); } catch (e) { j = null; }
  if (res.status === 401) throw new Error('The access key was rejected. Re-enter it in the extension settings.');
  if (!res.ok || !j) throw new Error((j && j.message) || 'n8n answered with status ' + res.status + '.');
  if (j.ok === false) throw new Error(j.message || 'The request did not go through.');
  return j;
}

async function refresh() {
  const j = await call('bootstrap');
  const campaigns = (j.campaigns || []).map((c) => ({ code: c.campaign_code, name: c.campaign_name, cat: c.category || 'Other' }));
  const saved = (j.contacts || []).map((c) => slugOf(c.linkedin_url)).filter(Boolean);
  await set({ campaigns: campaigns, saved: saved, contactCount: (j.contacts || []).length, syncedAt: Date.now() });
  return { campaigns: campaigns, saved: saved, contactCount: (j.contacts || []).length };
}

async function status(force) {
  const s = await get(['key', 'campaigns', 'saved', 'syncedAt', 'camp', 'contactCount']);
  if (!s.key) return { ok: true, connected: false };
  if (force || !s.campaigns || !s.syncedAt || Date.now() - s.syncedAt > FRESH_MS) {
    try { const r = await refresh(); Object.assign(s, r); }
    catch (e) { if (!s.campaigns) return { ok: false, connected: false, message: e.message }; }
  }
  const camp = s.camp && s.campaigns.some((c) => c.code === s.camp) ? s.camp : (s.campaigns[0] || {}).code;
  return { ok: true, connected: true, campaigns: s.campaigns, saved: s.saved || [], camp: camp, contactCount: s.contactCount || 0 };
}

async function add(p) {
  const j = await call('add', { prospects: [p] });
  const s = await get(['saved']);
  const saved = s.saved || []; const k = slugOf(p.linkedin_url);
  if (k && !saved.includes(k)) saved.push(k);
  await set({ saved: saved, camp: p.campaign_code });
  return { ok: true, message: j.message || '', queued: j.queued || 1 };
}

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const run = async () => {
    if (msg.type === 'status') return status(!!msg.force);
    if (msg.type === 'add') return add(msg.prospect);
    if (msg.type === 'setCamp') { await set({ camp: msg.camp }); return { ok: true }; }
    return { ok: false, message: 'Unknown request' };
  };
  run().then(reply, (e) => reply({ ok: false, message: e.message }));
  return true;
});
